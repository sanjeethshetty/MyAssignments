<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/404', function () {
    return view('errors.404');
});

Route::get('/home', 'AlbumPhotos@index');
Route::put('/delete_photo/{id}','AlbumPhotos@delete_photo');
Route::resource('albums','AlbumPhotos');

Route::get('/insert-json-file-to-database-table', function(){
	$json = file_get_contents(storage_path('demo.json'));
	$objs = json_decode($json,true);

	foreach ($objs as $obj)  {
		$data_insert = array(
            'userid'       =>   $obj["UserId"],
            'title'            =>  $obj["Title"],
            'id'            =>   $obj["Id"]
        );

		DB::table('albums')->insert($data_insert);
	}
	dd("Finished adding data in examples table");
});

Route::get('/insert-json-file-to-photos-table', function(){
	ini_set('max_execution_time', 300);
	$json = file_get_contents(storage_path('photos.json'));
	$objs = json_decode($json,true);

	foreach ($objs as $obj)  {
		$data_insert = array(
            'id'       =>   $obj["id"],
            'albumid'            =>  $obj["albumId"],
            'title'            =>   $obj["title"],
            'url'       =>   $obj["url"],
            'thumbnailUrl'            =>  $obj["thumbnailUrl"]
        );

		DB::table('photos')->insert($data_insert);
	}
	dd("Finished adding data in examples table");
});
