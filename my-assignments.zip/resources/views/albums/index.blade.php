@extends('albums.layout')
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
@section('content')
<div class="clearfix"></div><br/>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Album Lists</h2>
            </div>
        </div>
    </div>
    <div class="clearfix"></div><br/>
   
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
   
    <table class="table table-bordered">
        <tr>

            <th>Album Title</th>
            <th width="280px">Action</th>
        </tr>
        @foreach ($albums_view as $albums)
        <tr>

            <td>{{ $albums->title }}</td>
            <td>
                <form action="{{ route('albums.destroy',$albums->id) }}" method="POST">
   
                    <a class="btn btn-info" data-toggle="modal" data-target="#myModal" onclick="get_view({{ $albums->id }})">View</a>
    
                    <a class="btn btn-primary" href="{{ route('albums.edit',$albums->id) }}">Edit</a>
   
                    @csrf
                    @method('DELETE')
      
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>
  
    {!! $albums_view->links() !!}

      <!-- Modal -->
      <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog">
        
          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title">View Album</h4>
            </div>
            <div class="modal-body">
              <p><b>Title:</b> <span id="pview_title"> </span></p>
               <p><b>Photos:</b></p>
              <div id="photos_div">
              
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
          </div>
          
        </div>
      </div>
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.js"></script>     
 <script type="text/javascript">
function get_view(al_id){
    var _token = $("input[name='_token']").val();
  $.ajax({
      type: "GET",
      url: "http://localhost:8000/api/get_albums",
      dataType: "json",
      data: {_token: _token,"aid":al_id},
      success: function(data){ 
        $("#pview_title").text(data.title);
      },
      error: function() { 
        swal({
            type: 'error',
            title: 'Oops...',
            text: "Something went wrong! Please try again"
          });
         }
    }); // end of ajax
    fetch_photos_data(al_id);
    }

    function fetch_photos_data(al_id){
        var _token = $("input[name='_token']").val();
      $.ajax({
          type: "GET",
          url: "http://localhost:8000/api/get_photos",
          dataType: "json",
          data: {_token: _token,"aid":al_id},
          success: function(response){ 
            console.log(response);
            var photo_data = '';
            var rescount = response.length;
            for(var i = 1; i < rescount; i++){
                photo_data += '<img src="'+response[i]['url']+'" style="height:50px;width:50px;"/>&nbsp;';
                if(i%10==0)
                  {
                    photo_data +='<div class="clearfix"></div><br/>';
                  }
            }
            $("#photos_div").html(photo_data); 
          },
          error: function() { 
            swal({
                type: 'error',
                title: 'Oops...',
                text: "Something went wrong! Please try again"
              });
             }
        }); // end of ajax
    }
 </script>     
@endsection