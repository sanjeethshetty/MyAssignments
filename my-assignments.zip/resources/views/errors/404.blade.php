<!DOCTYPE html>
<html lang="en">
<head>
  <title>My Assignments</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
  <style type="text/css">
      @media (min-width: 1100px){
        .padding-copy{
            padding: 0px 90px;
        }
      }
      *{
        font-family: 'Poppins', sans-serif !important;
      }
      .home-btn{
            color: #404040;
            background: #FFCC00;
            padding: 11px 38px;
            font-size: 13px;
            border-radius: 3px;
            text-decoration: none !important;
      }
      .home-btn:hover{
        color: black !important;
      }
      .padding-copy{
        line-height: 1.7;
      }
  </style>
</head>
<body>

<table bgcolor="#F1F1F1" width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
        
        <tr>
            <td>
               
            </td>
        </tr>
        <tr>
            <td>
                <table width="87%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr>
                        <td valign="top" style="padding-top:40px; padding-bottom:40px;">

                            <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
                                <tr>
                                    <td>
                                        <table cellspacing="0" cellpadding="0" width="100%" align="center" border="0">
                                            <tr>
                                                <td>

                                                    <div class="container"> 
                                                        <div class="row">
                                                            <div style="margin: 70px 0;" class="col-md-6 text-center">
                                                                <img width="80%" height="auto" src="../images/404.svg">
                                                            </div>
                                                            <div class="col-md-6 text-center m-auto pb-4">
                                                                <h1 style="color: #C63E47;font-weight: 600;font-size: 48px;" class="text-center">Oops! You’re lost...</h1>
                                                                <h5 style="color: #404040;" class="text-center padding-copy mt-4 mb-5">The page you are looking for might have been moved, renamed, or might never existed.</h5>
                                                                <a class="home-btn" href="/">GO HOME</a>
                                                            </div>
                                                            
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>

                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>

</body>
</html>
