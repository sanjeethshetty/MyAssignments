<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Albums;
use App\Photos;

class AlbumPhotos extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $albums_view = Albums::latest()->paginate(10);
        return view('albums.index',compact('albums_view'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
         $albums = Albums::where('id',$id)->first();
         $photos_data = Photos::where('albumid',$id)->get();
        return view('albums.edit',compact('albums','photos_data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
         try {
            $request->validate([
                'title' => 'required',
                'ptitle' => 'required',
                'purl' => 'required',
                'pturl' => 'required',
            ]);
            //album update
            $form_data = array(
                'title'       =>   $request->input('title')
            );

            Albums::whereId($id)->update($form_data);

            $pid = $request->pid; 
            $ptitle = $request->ptitle; 
            $purl = $request->purl; 
            $pturl = $request->pturl; 

            //photos update
             foreach($pid as $index => $pid) {
                $req_data = array(
                        'title'       =>   $ptitle[$index],
                        'url'       =>   $purl[$index],
                        'thumbnailUrl'       =>   $pturl[$index]
                    );

                 $update=Photos::whereId($pid)->update($req_data);
             }
            return redirect()->route('albums.index')
                            ->with('success','Album updated successfully');
        } catch (Exception $e) {
           return redirect()->route('albums.index')
                        ->with('error','Failed');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if(!empty($id))
        {
        Albums::whereId($id)->delete();
  
        return redirect()->route('albums.index')
                        ->with('success','Album deleted successfully');
        }else
        {
            abort(404);
        }
    }

    public function delete_photo($id)
    {
        if(!empty($id))
        {
            $data=Photos::findOrFail($id);
            $data->delete();

            return 1;
        }else
        {
            abort(404);
        }
    }
}
