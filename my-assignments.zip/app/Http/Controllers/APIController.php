<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Albums;
use App\Photos;


class APIController extends Controller
{
    public function get_albums(){
	        try{
	        	if($_GET['aid'])
	        	{
	        		$album_id = $_GET['aid'];
		            $albums = Albums::where('id',$album_id)->first();
		            return json_encode($albums);
	        	}else
	        	{
	        		$title = $_GET['title'];
		            $albums = Albums::where('title',$title)->first();
		            return json_encode($albums);
	        	}
	            
	        }
	        catch(Exception $e){
	            $msg = $e->getMessage();
	        }
    }

    public function get_photos(){
	        try{
	        	if($_GET['aid'])
	        	{
	        		$album_id = $_GET['aid'];
		            $albums = Photos::where('albumid',$album_id)->get();
		            return json_encode($albums);
	        	}else
	        	{
	        		$title = $_GET['title'];
		            $albums = Photos::where('title',$title)->get();
		            return json_encode($albums);
	        	}
	            
	        }
	        catch(Exception $e){
	            $msg = $e->getMessage();
	        }
    }
}
