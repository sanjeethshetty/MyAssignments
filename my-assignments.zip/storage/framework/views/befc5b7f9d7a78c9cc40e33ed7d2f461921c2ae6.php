   
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Edit Albums</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('albums.index')); ?>"> Back</a>
            </div>
        </div>
    </div>
   
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
  
    <form action="<?php echo e(route('albums.update',$albums->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
   
         <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Album Title:</strong>
                    <input type="text" name="title" value="<?php echo e($albums->title); ?>" class="form-control" placeholder="title" required>
                </div>
            </div>

             <table class="table table-bordered">
                <tr>
                    <th>Photo</th>
                    <th>Title</th>
                    <th>URL</th>
                    <th>Thumbnail URL</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $photos_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <td><img src="<?php echo e($photos->url); ?>" style="height:50px;width:50px;"/></td>
                    <td> <input type="text" name="ptitle[]" value="<?php echo e($photos->title); ?>" class="form-control" placeholder="photos title" required></td>
                    <td> <input type="text" name="purl[]" value="<?php echo e($photos->url); ?>" class="form-control" placeholder="photos url" required></td>
                     <td> <input type="text" name="pturl[]" value="<?php echo e($photos->thumbnailUrl); ?>" class="form-control" placeholder="photos turl" required></td>
                    <input type="hidden" name="pid[]" value="<?php echo e($photos->id); ?>">
                    <td><a onclick="delete_photo(<?php echo e($photos->id); ?>)" class="btn btn-danger">Delete</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>

          
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
              <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </div>
   
    </form>
    <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.js"></script>
    <script type="text/javascript">
        function delete_photo(pid)
        {
             var _token = $("input[name='_token']").val();
              var res = confirm('Do you really want to delete this?');
              if(res){
              $.ajax({
                          type: "PUT",
                          url: "../../delete_photo/"+pid,
                           dataType: "json",
                           data: {_token: _token},
                          success: function(response){
                            Swal.fire({
                                        type: 'success',
                                        title: 'Success',
                                        text: 'Deleted Successfully.',
                                        allowOutsideClick: false
                                      }).then(okay => {
                                           if (okay) {
                                            location.reload();
                                               
                                          } // end of if okay
                                        });
                          }
                               
                        }); // end of ajax
              }  
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('albums.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my-assignments\resources\views/albums/edit.blade.php ENDPATH**/ ?>